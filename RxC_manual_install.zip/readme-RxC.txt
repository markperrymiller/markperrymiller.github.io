Unzip the contents of this archive to a temporary file.  After doing so, copy the the files to the following locations:

cmdialog.vbx:   windows/system directory
commdlg.dll:	windows/system directory
vbrun300.dll:	windows/system directory
rxc.exe:	user defined "program" folder
rxc.hlp:	user defined "program" folder
table1.rxc	user defined "program" folder


Double-click the file "RxC.exe" to run the program.
