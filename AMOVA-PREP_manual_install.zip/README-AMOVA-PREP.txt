After extracting the contents of this archive, copy "cmdialog.vbx", "commdlg.dll", and "vbrun300.dll" to your windows/system directory.  The remaining files can be moved to any location on your computer.  Run "amovaprp.exe" to start the program.



cmdialog.vbx   program file   windows\system directory

commdlg.dll    program file   windows\system directory

vbrun300.dll   program file   windows\system directory

amovaprp.exe   program file   program directory

twolevel.dat   sample data    program directory

threelvl.dat   sample data    program directory

amovaprp.hlp   help file      program directory

